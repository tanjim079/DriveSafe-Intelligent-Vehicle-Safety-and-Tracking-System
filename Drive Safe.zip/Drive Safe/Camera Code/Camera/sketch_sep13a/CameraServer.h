#include <WiFi.h>
#include "esp_camera.h"
#include <WebServer.h>

WebServer server(80);

void handleJPGStream() {
  WiFiClient client = server.client();
  String response = "HTTP/1.1 200 OK\r\n";
  response += "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n\r\n";
  client.print(response);

  while (client.connected()) {
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
      Serial.println("Camera capture failed");
      break;
    }

    // Send JPEG frame header
    client.printf("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n", fb->len);
    client.write(fb->buf, fb->len);
    client.print("\r\n");

    esp_camera_fb_return(fb);

    // Tiny delay to avoid overload
    if (!client.connected()) break;
    delay(10);
  }
}

void handleRoot() {
  String html = "<html><body>";
  html += "<h1>ESP32-CAM Stream</h1>";
  html += "<img src=\"/stream\" width='320' height='240'>";
  html += "</body></html>";
  server.send(200, "text/html", html);
}

void startCameraServer() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/stream", HTTP_GET, handleJPGStream);
  server.begin();
  Serial.println("HTTP server started");
}